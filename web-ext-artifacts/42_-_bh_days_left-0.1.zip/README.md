# web-ext

Install : `npm install --global web-ext`
Test : `web-ext run`
Linter : `web-ext lint`
Package : `web-ext build`

More help : <https://extensionworkshop.com/documentation/develop/getting-started-with-web-ext/>
